#include <REGX52.H>



void Delay(unsigned int x)// input a number
{
	int t = 0;
	for(t = 0;t < x;t ++)
			{
			unsigned char data i, j;
			i = 11;
			j = 190;
					do
					{
						while (--j);
					}while (--i);
			}
}


unsigned char LEDNUM = 0;
void main()
{
		P2 = ~0x01;// 0000 0001
		while(1)
		{
				if(P3_1 == 0)
						{
							Delay(20);
							while(P3_1 == 0);
							LEDNUM++;
							if(LEDNUM == 8)
							{
									LEDNUM = 0;
							}
							P2 = ~(0x01 << LEDNUM);
						}
				if(P3_0 == 0)
				{
						Delay(20);
						while(P3_0 == 0);
						Delay(20);
						LEDNUM--;
						if(LEDNUM == -1)
						{
								LEDNUM = 7;
						}
						P2 = ~(0x01 << LEDNUM);
					
				}
			
			
			
			
			
			
			
			
		}
		
	
	
	
}